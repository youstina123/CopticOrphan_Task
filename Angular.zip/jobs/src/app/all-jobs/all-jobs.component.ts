import { NgFor } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { JobsServiceService } from '../jobs-service.service';
import { HttpClientModule } from '@angular/common/http';
import { Job } from '../Interfaces/job';
import { Router } from '@angular/router';

@Component({
  selector: 'app-all-jobs',
  imports: [NgFor,HttpClientModule],
  templateUrl: './all-jobs.component.html',
  styleUrl: './all-jobs.component.css'
})
export class AllJobsComponent implements OnInit {
  jobs:Job[]=[];
  constructor(private jobService: JobsServiceService,private route: Router) {

  }
  ngOnInit(): void {
    this.jobService.getAllPositions().subscribe((data: any[]) => {
      this.jobs = data;
    });
  }


  ShowDetails(job: Job) {
    this.route.navigate(['job-details/'+job.id]);
  }

}
