import { NgFor, NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { JobsServiceService } from '../jobs-service.service';
import { Job } from '../Interfaces/job';


@Component({
  selector: 'app-job-details',
  imports: [NgFor,NgIf],
  templateUrl: './job-details.component.html',
  styleUrl: './job-details.component.css'
})

export class JobDetailsComponent implements OnInit {

  job: Job | undefined;
  constructor(
    private activatedRoute: ActivatedRoute,
    private route: Router,private jobService: JobsServiceService
  ) { }

  ngOnInit(): void { this.activatedRoute.params.subscribe(params => { const jobId = +params['id']; 
     this.jobService.getJobById(jobId).subscribe(response => { this.job = response; }); }); 
     console.log(this.job)
    }


  Apply(job:Job) {
    this.route.navigate(['/apply/'+job.id]);
  }

  Navigate() {
    this.route.navigate(['/']);
  }
}
