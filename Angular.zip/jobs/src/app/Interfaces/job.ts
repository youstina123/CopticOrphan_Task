export interface Job {
    id:number,
    name: string;
    description: string;
    salary: number;
  }
  