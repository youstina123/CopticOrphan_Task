export interface JobApplication {
    applicantName: string;
    clientFileName: string;
    positionID: number;
    cv?: string;
  }
  