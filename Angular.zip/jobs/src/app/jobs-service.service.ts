import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Job } from './Interfaces/job';
import { JobApplication } from './Interfaces/JobApplication';

@Injectable({
  providedIn: 'root'
})
export class JobsServiceService {


  apiUrl = 'http://localhost:7161/api/jobs';

  constructor(private http: HttpClient) { }

  getAllPositions(): Observable<Job[]> {
    return this.http.get<Job[]>(`${this.apiUrl}/getlist`);
  }
  getJobById(id: number): Observable<Job> {
    console.log(id);
    return this.http.get<Job>(`${this.apiUrl}/getdetails/${id}`);
  }

  submitApplication(application: JobApplication): Observable<any> {
    console.log(application);
    return this.http.post<any>(`${this.apiUrl}/aply`, application);
  }

}
