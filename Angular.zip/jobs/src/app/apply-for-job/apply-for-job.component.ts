import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { JobApplication } from '../Interfaces/JobApplication';
import { JobsServiceService } from '../jobs-service.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-apply-for-job',
  imports: [FormsModule],
  templateUrl: './apply-for-job.component.html',
  styleUrl: './apply-for-job.component.css'
})
export class ApplyForJobComponent implements OnInit {
  application: JobApplication = { applicantName: '', cv: undefined,clientFileName:'',positionID:0};

constructor(    private activatedRoute: ActivatedRoute,private jobService: JobsServiceService) {
  
}
  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => { const jobId = +params['id']; 
        this.application.positionID = jobId;
  })
  }

  uploadFile(event: any): void {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
        this.application.cv = reader.result?.toString();
        this.application.clientFileName = event.target.files[0].name;
    };

  }

  submitApplication(): void {
    this.jobService.submitApplication(this.application).subscribe(response => {
      console.log('Application submitted successfully', response);
    });
  }
}


