﻿namespace Jobs.Core.DTOs
{
    public class PositionApplicationsDTO
    {
        public int ID { get; set; }

        public string CV { get; set; }

        public string ApplicantName { get; set; }

        public string ClientFileName { get; set; }

        public string DbFilename { get; set; }

        public int PositionID { get; set; }
    }
}
