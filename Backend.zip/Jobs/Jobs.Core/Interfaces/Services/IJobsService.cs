﻿using Jobs.Core.DTOs;
using Jobs.Core.Models;

namespace Jobs.Core.Interfaces.Services
{
    public interface IJobsService
    {
        Task<ResponseDTO> Apply(PositionApplicationsDTO positionApplicationsDTO);
        ResponseDTO GetAll();
        ResponseDTO GetDetails(int ID);
    }
}
