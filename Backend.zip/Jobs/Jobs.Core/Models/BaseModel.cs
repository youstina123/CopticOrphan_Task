﻿namespace Jobs.Core.Models
{
    public class BaseModel
    {
        public bool IsDeleted { get; set; } = false;
    }
}
