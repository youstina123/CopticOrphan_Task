﻿using System.ComponentModel.DataAnnotations;

namespace Jobs.Core.Models
{
    public class Position : BaseModel
    {
        public int ID { get; set; }
        
        public string Name { get; set; }
        
        public float Salary { get; set; }

        public string Description { get; set; }
    }
}
