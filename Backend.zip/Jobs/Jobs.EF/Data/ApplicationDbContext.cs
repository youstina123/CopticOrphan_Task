﻿using Jobs.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace Jobs.EF.Data
{
    public class ApplicationDbContext : DbContext
    {
        #region DbSets
        public DbSet<Position> Positions { get; set; }
        public DbSet<PositionApplication> PositionApplications { get; set; }

        #endregion

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Position>()
                .HasData(
                new Position()
                {
                    ID = 1,
                    Name = "JR .net Developer",
                    Salary = 35000,
                    Description = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae accusamus voluptatem error natus earum animi dolores, iure qui repellendus repellat perferendis, molestiae cumque dolore pariatur praesentium illo. Nihil, nostrum odit!",
                    IsDeleted = false,
                },
                new Position()
                {
                    ID = 2,
                    Name = "SR .net Developer",
                    Salary = 50000,
                    Description = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae accusamus voluptatem error natus earum animi dolores, iure qui repellendus repellat perferendis, molestiae cumque dolore pariatur praesentium illo. Nihil, nostrum odit!",
                    IsDeleted = false,
                },
                new Position()
                {
                    ID = 3,
                    Name = "JR Full-Stack Developer",
                    Salary = 400000,
                    Description = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae accusamus voluptatem error natus earum animi dolores, iure qui repellendus repellat perferendis, molestiae cumque dolore pariatur praesentium illo. Nihil, nostrum odit!",
                    IsDeleted = false,
                },
                new Position()
                {
                    ID = 4,
                    Name = "SR Full-Stack Developer",
                    Salary = 75000,
                    Description = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae accusamus voluptatem error natus earum animi dolores, iure qui repellendus repellat perferendis, molestiae cumque dolore pariatur praesentium illo. Nihil, nostrum odit!",
                    IsDeleted = false,
                });
        }
    }
}
