﻿using AutoMapper;
using Jobs.Core.DTOs;
using Jobs.Core.Enums;
using Jobs.Core.Interfaces;
using Jobs.Core.Interfaces.Services;
using Jobs.Core.Models;

namespace Jobs.EF.Services
{
    public class JobService : IJobsService
    {
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public JobService(IMapper mapper, IUnitOfWork unitOfWork)
        {
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public async Task<ResponseDTO> Apply(PositionApplicationsDTO positionApplicationsDTO)
        {
            ResponseDTO result;

            bool jobExists = _unitOfWork.Repository<Position>().IsExist(c => c.ID == positionApplicationsDTO.PositionID);

            if (jobExists)
            {
                result = await RegisterApplication(positionApplicationsDTO);
            }
            else
            {
                result = await JobNotFount();
            }

            return result;
        }

        public async Task<ResponseDTO> RegisterApplication(PositionApplicationsDTO positionApplicationsDTO)
        {
            bool isCVSaved = SaveCV(positionApplicationsDTO);
            if (!isCVSaved) 
            {
                return new ResponseDTO(ResponseStatusCode.ServerError, false, positionApplicationsDTO, "your CV hase some issue");
            }
            PositionApplication positionApplication = _mapper.Map<PositionApplication>(positionApplicationsDTO);
            _unitOfWork.Repository<PositionApplication>().Add(positionApplication);
            await _unitOfWork.SaveChangesAsync();
            return new ResponseDTO(ResponseStatusCode.Ok, true, positionApplication, "your applicatation recived successffully");
        }

        private bool SaveCV(PositionApplicationsDTO positionApplicationsDTO)
        {
            bool isSuccess = true;
            try 
            {
                byte[] cvBytes = Convert.FromBase64String(positionApplicationsDTO.CV);
                positionApplicationsDTO.DbFilename = Guid.NewGuid().ToString() + Path.GetExtension(positionApplicationsDTO.ClientFileName);
                if (!Directory.Exists($"CVs"))
                    Directory.CreateDirectory($"CVs");
                Path.GetExtension(positionApplicationsDTO.ClientFileName);
                File.WriteAllBytes($"CVs\\{positionApplicationsDTO.DbFilename}", cvBytes);

            }
            catch (Exception ex)
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public async Task<ResponseDTO> JobNotFount()
        {
            return new ResponseDTO(ResponseStatusCode.NotFound, false, new PositionDTO(), "The position you are trying to reach is not found");
        }

        public ResponseDTO GetAll()
        {
            IEnumerable<Position> Jobs = _unitOfWork.Repository<Position>().GetAll();
            return new ResponseDTO(ResponseStatusCode.Ok, true, _mapper.Map<IEnumerable<PositionDTO>>(Jobs), "All Positions");
        }

        public ResponseDTO GetDetails(int ID)
        {
            Position Job = _unitOfWork.Repository<Position>().Find(j => j.ID == ID);
            if(Job is not null)
            {
                return new ResponseDTO(ResponseStatusCode.Ok, true, _mapper.Map<PositionDTO>(Job), "Position Details");
            }
            else
            {
                return new ResponseDTO(ResponseStatusCode.NotFound, true, null, "This job not found so Please check the ID");
            }
        }
    }
}
